#!/bin/sh

echo "Hello, World"
exec sleep infinity
